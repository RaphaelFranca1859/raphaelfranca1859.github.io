# Portfólio — Raphael França

Site pessoal de portfólio de **Raphael França**, desenvolvedor e analista de dados.
Foco em **desenvolvimento de sistemas web, dados e automação** com Python.

🔗 **Online:** https://raphaelfranca1859.github.io/  
*(ou `https://raphaelfranca1859.github.io/<nome-do-repo>/` se usar um repositório de projeto)*

---

## ✨ Sobre o projeto

Página única, responsiva e sem dependências de build — apenas **HTML, CSS e JavaScript puro**.
Tema escuro inspirado no **Dracula** (VS Code), com efeitos de rolagem fluidos
(barra de progresso, parallax no hero, reveals em cascata) e acessibilidade básica
(navegação por teclado e respeito a `prefers-reduced-motion`).

### Seções
- **Hero** — apresentação e chamada principal
- **Skills** — Programação & Web · Dados & Bancos · Engenharia & Sistemas
- **Projetos** — automações, dashboards e sistemas (com status e stack de cada um)
- **Sobre** — trajetória e foco
- **Contato** — e-mail, LinkedIn, GitHub e WhatsApp

---

## 🛠️ Tecnologias da página

| Camada | Stack |
|---|---|
| Estrutura | HTML5 semântico |
| Estilo | CSS3 (custom properties, grid, flexbox) |
| Interação | JavaScript (IntersectionObserver, sem frameworks) |
| Tipografia | Space Grotesk · IBM Plex Sans · IBM Plex Mono (Google Fonts) |

> Não há etapa de build, bundler ou backend. É só abrir o `index.html`.

---

## ▶️ Rodar localmente

### Opção 1 — VS Code + Live Server (recomendado)
1. Abra a pasta no VS Code (`File → Open Folder`).
2. Instale a extensão **Live Server** (Ritwick Dey).
3. Botão direito em `index.html` → **Open with Live Server**.
4. Abre em `http://127.0.0.1:5500` e recarrega sozinho ao salvar.

### Opção 2 — Python (sem extensão)
```bash
python -m http.server 5500
# acesse http://localhost:5500
```

---

## 🚀 Deploy no GitHub Pages

1. Suba este projeto para um repositório no GitHub (veja os comandos abaixo).
2. No repositório: **Settings → Pages**.
3. Em **Source**, escolha **Deploy from a branch**.
4. Selecione a branch `main` e a pasta `/ (root)` → **Save**.
5. Aguarde ~1 minuto. A URL pública aparece no topo da própria página de Pages.

> O arquivo `.nojekyll` já está incluído para o GitHub Pages servir os arquivos
> sem processamento do Jekyll.

---

## 📂 Estrutura

```
.
├── index.html      # a página inteira (HTML + CSS + JS)
├── .nojekyll       # desativa o Jekyll no GitHub Pages
├── .gitignore
├── LICENSE
└── README.md
```

---

## 📫 Contato

- **E-mail:** raphaeloliveira1859@gmail.com
- **LinkedIn:** https://www.linkedin.com/in/raphael-fran%C3%A7a-a2167a94/
- **GitHub:** https://github.com/RaphaelFranca1859
- **WhatsApp:** +55 77 99906-6810

---

© 2026 Raphael França. Distribuído sob a licença MIT (veja `LICENSE`).
